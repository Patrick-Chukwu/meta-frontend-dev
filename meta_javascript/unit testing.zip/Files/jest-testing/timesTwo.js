// Task 1: Code the timesTwo function declaration

function timesTwo(number) {
  return 2 * number;
}

// Task 2: Export the timesTwo function as a module
module.exports = timesTwo;
